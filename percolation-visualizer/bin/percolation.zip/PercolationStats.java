import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
        private final double[] ratio;
        private final int trials;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException("Invalid input in constructor");
        }

        this.ratio = new double[trials];
        this.trials = trials;

        for (int i = 0; i < trials; i++) {
            Percolation p = new Percolation(n);
            while (!p.percolates()) {
                int rowR = StdRandom.uniform(n);
                int colR = StdRandom.uniform(n);
                p.open(rowR+1, colR+1);
            }

            this.ratio[i] = (double) (p.numberOfOpenSites()) / (double) (n*n);
        }
    }

    // sample mean of percolation threshold
    public double mean() {
        return StdStats.mean(this.ratio);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return StdStats.stddev(this.ratio);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - (1.96d * stddev() / Math.sqrt(trials));
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean() + (1.96d * stddev() / Math.sqrt(trials));
    }

   // test client (see below)
   public static void main(String[] args) {
       int n = StdIn.readInt();
       int t = StdIn.readInt();
       PercolationStats s = new PercolationStats(n, t);
       System.out.println("mean                    = " + s.mean());
       System.out.println("stddev                  = " + s.stddev());
       System.out.println("95% confidence interval = [" + s.confidenceLo() +  ", " + s.confidenceHi() + "]");
   }

}   
